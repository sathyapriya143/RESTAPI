import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule, Routes } from '@angular/router';
import { FetchComponent } from './fetch/fetch.component';
import { FormComponent } from './form/form.component';
import { HttpclientComponent } from './httpclient/httpclient.component';
import { SingInComponent } from './sing-in/sing-in.component';

const routes: Routes = [
  {
    path: 'Form ',
    component: FormComponent
  },

  {
    path: 'signIn ',
    component: SingInComponent
  },

  {
    path: 'Httpclient',
    component: HttpclientComponent
  },



  {
    path: ' FetchFetchComponent ',
    component: FetchComponent 
  }
];

@NgModule({
  imports: [CommonModule,RouterModule.forRoot(routes)],
  exports: [RouterModule],
  declarations: []
})
export class AppRoutingModule { }
